/app/progress/dlc91d/bin/probkup online /db/prod/mfgprod /backup/db/2011/1021/prod1 < /backup/db/2011/bak.in

