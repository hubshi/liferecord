#!/bin/sh
# Script to start multi-user session of MFG/PRO
 
# tokens:
# &DLC = Progress Directory
# &CLIENT-DB-CONNECT = command line to connect to each db in dbset
 
stty intr '^c'
DLC=/app/tools/progress/91d09;export DLC
. $DLC/bin/slib_env
PATH=$PATH:$DLC/bin;export PATH
PROMSGS=$DLC/promsgs;export PROMSGS
PROTERMCAP=$DLC/protermcap;export PROTERMCAP
PS1='$$ ';export PS1
PROPATH=.,/var/tmp/showa,/app/mfgpro/showa/chrcli,/app/mfgpro/showa/chrcli/xrc,/app/mfgpro/showa/chrcli/bbi;export PROPATH
 
#
# Set terminal type.
#
if [ ${TERM:-NULL} = NULL ]
then  
    echo
    echo "Please enter your terminal type: \c"
    read TERM
    export TERM
fi
 
#
# Start MFG/PRO.
# 
cd /var/tmp/tmp	# change to home directory
 
# exec $DLC/bin/_progres &DB etc
$DLC/bin/_progres -c 30 -d mdy -yy 1920 -Bt 350 -D 100 -mmax 3000 -nb 200 -s 63 -noshvarfix -p /mnt/hgfs/tmp/chpwd.p -pf /app/mfgpro/showa/Production.pf  
