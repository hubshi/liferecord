/app/progress/dlc91d/bin/prorest /test/db/demo/mfgdemo /backup/db/2011/1021/prod1 < /backup/db/2011/rst.in

